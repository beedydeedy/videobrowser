﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using MediaBrowser.Library.Plugins;
using MediaBrowser.Library.Entities;
using MediaBrowser.Library.Logging;
using MediaBrowser;
using MediaBrowser.Library.Configuration;
using MediaBrowser.Library;

//******************************************************************************************************************
//  This class is the heart of your plug-in Theme.  It is instantiated by the initial loading logic of MediaBrowser.
//
//  For your project to build you need to be sure the reference to the MediaBrowser assembly is current.  More than
//  likely, it is broken in this template as the template cannot copy binaries, plus it would probably be out of date
//  anyway.  Expand the References tree in the Solution Explorer to the right and make sure you have a good reference
//  to a current version of the mediabrowser.dll.
//
//  For your project to load as a MediaBrowser Plug-in you need to build your release .dll and copy it to 
//  c:\program data\mediabrowser\plugins.  The Configurator will do this automatically if provided a valid 
//  plugin_info.xml file and location for your .dll
//******************************************************************************************************************

namespace $safeprojectname$ {
    class Plugin : BasePlugin
    {

        static readonly Guid $safeprojectname$Guid = new Guid("$guid1$");

        private MyConfig config;

        /// <summary>
        /// The Init method is called when the plug-in is loaded by MediaBrowser.  You should perform all your specific initializations
        /// here - including adding your theme to the list of available themes.
        /// </summary>
        /// <param name="kernel"></param>
        public override void Init(Kernel kernel)
        {
            try
            {
                //the AddTheme method will add your theme to the available themes in MediaBrowser.  You need to call it and send it
                //resx references to your mcml pages for the main "Page" selector and the MovieDetailPage for your theme.
                //The template should have generated some default pages and values for you here but you will need to create all the 
                //specific mcml files for the individual views (or, alternatively, you can reference existing views in MB.
                kernel.AddTheme("$safeprojectname$", "resx://$safeprojectname$/$safeprojectname$.Resources/Page#Page$safeprojectname$", "resx://$safeprojectname$/$safeprojectname$.Resources/DetailMovieView#$safeprojectname$MovieView",config);

                //The AddConfigPanel method will allow you to extend the config page of MediaBrowser with your own options panel.
                //You must create this as an mcml UI that fits within the standard config panel area.  It must take Application and 
                //FocusItem as parameters.  The project template should have generated an example ConfigPage.mcml that you can modify
                //or, if you don't wish to extend the config, remove it and the following call to AddConfigPanel.  This call is in 
                //a conditional because we can only perform these operations when in MediaCenter (we can be called from other places)
                bool isMC = AppDomain.CurrentDomain.FriendlyName.Contains("ehExtHost");
                if (isMC) 
                {                    
                    config = new MyConfig();
                    kernel.AddConfigPanel("$safeprojectname$ Options", "resx://$safeprojectname$/$safeprojectname$.Resources/ConfigPanel#ConfigPanel", config);
                    //If you want to add any context menus they need to be inside this logic as well.
                }
                else Logger.ReportInfo("Not creating menus for $safeprojectname$.  Appear to not be in MediaCenter.  AppDomain is: " + AppDomain.CurrentDomain.FriendlyName);

                //The AddStringData method will allow you to extend the localized strings used by MediaBrowser with your own.
                //This is useful for adding descriptive text to go along with your theme options.  If you don't have any theme-
                //specific options or other needs to extend the string data, remove the following call.
                kernel.StringData.AddStringData(MyStrings.FromFile(MyStrings.GetFileName("$safeprojectname$-")));

                //Tell the log we loaded.
                Logger.ReportInfo("$safeprojectname$ Theme Loaded.");
            }
            catch (Exception ex)
            {
                Logger.ReportException("Error adding theme - probably incompatable MB version", ex);
            }

        }

        public override string Name
        {
            //provide a short name for your theme - this will display in the configurator list box
            get { return "$safeprojectname$ Theme"; }
        }

        public override string Description
        {
            //provide a longer description of your theme - this will display when the user selects the theme in the plug-in section
            get { return "A new Theme for MediaBrowser"; }
        }

        //Only un-comment this if you have a rich description resource
        //public override string RichDescURL
        //{
        //    //You can return a fully-qualified URI to a resource that displays a rich description of your plugin here
        //    get { return "http://www.mysite.com/$safeprojectname$Desc.htm"; }
        //}

        // Return the lowest version of MediaBrowser with which this plug-in is compatable
        public override System.Version RequiredMBVersion
        {
            get
            {
                return new System.Version(2,5,0,0);
            }
        }

    }


}
